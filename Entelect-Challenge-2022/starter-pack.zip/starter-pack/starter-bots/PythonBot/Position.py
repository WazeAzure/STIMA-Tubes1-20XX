class Position:
    def __init__(self, x, y) -> None:
        self.x = x
        self.y = y