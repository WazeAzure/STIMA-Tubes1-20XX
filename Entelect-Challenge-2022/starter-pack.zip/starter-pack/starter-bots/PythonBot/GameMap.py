class Game_Map:
    def __init__(self, scout_towers, nodes) -> None:
        self.scout_towers = scout_towers
        self.nodes = nodes