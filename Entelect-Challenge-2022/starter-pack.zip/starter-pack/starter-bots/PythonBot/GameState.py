class GameState:
    def __init__(self, world, game_objects, population_tiers) -> None:
        self.world = world
        self.game_objects = game_objects
        self.population_tiers = population_tiers