class World:
    def __init__(self, size, current_tick, map_object) -> None:
        self.size = size
        self.current_tick = current_tick
        self.map = map_object