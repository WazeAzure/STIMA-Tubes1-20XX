class TierResourceConstraints:
    def __init__(self, food, wood, stone) -> None:
        self.food = food
        self.wood = wood
        self.stone = stone