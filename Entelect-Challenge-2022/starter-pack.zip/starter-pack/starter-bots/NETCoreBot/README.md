# .Net Readme

## Installation

To run the .Net bot is requires _`.Net6`_ to run. This can be obtained from https://dotnet.microsoft.com/en-us/download/dotnet/6.0.


## Running

You can use **Visual studio** 2019 or 2022 to run the bot. Alternatively you can use **VSCode** to run, you will need to install the C# extensions by **Microsoft** to run it and may need some extra configurations to get it to run