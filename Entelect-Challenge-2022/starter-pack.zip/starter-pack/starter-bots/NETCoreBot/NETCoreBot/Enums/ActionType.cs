﻿namespace NETCoreBot.Enums
{
    public enum ActionType
    {
        Error = 0,
        Scout = 1,
        Mine = 2,
        Farm = 3,
        Lumber = 4,
        StartCampfire = 5
    }
}
