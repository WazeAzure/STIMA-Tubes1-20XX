﻿namespace NETCoreBot.Enums
{
    public enum ResourceType
    {
        Error,
        Wood,
        Food,
        Stone,
        Gold,
        Heat
    }
}
