﻿namespace NETCoreBot.Enums
{
    public enum GameObjectType
    {
        Error = 0,
        PlayerBase = 1,
        ScoutTower = 2,
        ResourceNode = 3
    }
}
