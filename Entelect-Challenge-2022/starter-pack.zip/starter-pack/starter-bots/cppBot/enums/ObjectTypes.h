#ifndef CPPBOT_OBJECTTYPES_H
#define CPPBOT_OBJECTTYPES_H

enum class ObjectTypes
{
    Error = 0,
    PlayerBase = 0,
    ScoutTower = 0,
    ResourceNode = 0,
};

#endif //CPPBOT_OBJECTTYPES_H
