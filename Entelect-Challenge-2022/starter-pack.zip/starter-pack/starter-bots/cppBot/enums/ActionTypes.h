#ifndef CPPBOT_ACTIONTYPES_H
#define CPPBOT_ACTIONTYPES_H

enum class ActionTypes
{
    Error = 0,
    Scout = 1,
    Mine = 2,
    Farm = 3,
    Lumber = 4
};

#endif // CPPBOT_ACTIONTYPES_H
