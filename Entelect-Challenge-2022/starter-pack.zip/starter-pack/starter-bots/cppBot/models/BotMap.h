#include <iostream>
#include <vector>

//
// Created by megan.humphreys on 2022/03/21.
//

#ifndef CPPBOT_BOT_MAP_H
#define CPPBOT_BOT_MAP_H

struct BotMap
{
    std::vector<std::string> scoutTowers;
    std::vector<std::string> nodes;
};

#endif //CPPBOT_BOT_MAP_H
