//
// Created by fabio.loreggian on 2021/03/03.
//

#ifndef CPPBOT_POSITION_H
#define CPPBOT_POSITION_H

struct Position
{
    int x;
    int y;
};

#endif //CPPBOT_POSITION_H
