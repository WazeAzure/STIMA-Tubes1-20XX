#include <iostream>
#include "Map.h"

#ifndef CPPBOT_WORLD_WORLDAMEOBJECT_H

struct World
{
    int size;
    int currentTick;
    Map map;
};

#endif //CPPBOT_GAMEOBJECT_H
