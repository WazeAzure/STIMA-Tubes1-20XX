//
// Created by fabio.loreggian on 2021/03/03.
//

#ifndef CPPBOT_REGENERATION_RATE_H
#define CPPBOT_REGENERATION_RATE_H

struct RegenerationRate
{
    int ticks;
    int amount;
};

#endif //CPPBOT_REGENERATION_RATE_H
