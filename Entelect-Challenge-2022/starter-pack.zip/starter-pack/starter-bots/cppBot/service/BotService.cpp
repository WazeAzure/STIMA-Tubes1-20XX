#include "BotService.hpp"

/**
 * Main Function to calculate the next action here
 */
void BotService::computeNextPlayerAction(std::promise<void> &startTask) {
    
}


