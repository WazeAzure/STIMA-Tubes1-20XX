package Models.Dtos.EngineConfigClasses;

import java.util.List;

public class RegenerationRateRange {
    public List<Integer> TickRange;
    public List<Integer> AmountRange;
}
