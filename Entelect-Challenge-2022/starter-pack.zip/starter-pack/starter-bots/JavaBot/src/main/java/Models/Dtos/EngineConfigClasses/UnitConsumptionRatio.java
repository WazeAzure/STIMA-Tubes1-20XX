package Models.Dtos.EngineConfigClasses;

public class UnitConsumptionRatio {
    public double Food;
    public double Wood;
    public double Stone;
    public double Gold;
    public double Heat;
}
