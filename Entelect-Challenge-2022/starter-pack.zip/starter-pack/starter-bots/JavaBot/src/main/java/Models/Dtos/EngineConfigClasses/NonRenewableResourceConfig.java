package Models.Dtos.EngineConfigClasses;

import java.util.List;

public class NonRenewableResourceConfig extends ResourceConfig {
    public List<Integer> AmountRange;
}
