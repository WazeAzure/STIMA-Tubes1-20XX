package Models.Dtos.EngineConfigClasses;

public class ResourceImportance {
    public double Food;
    public double Heat;
}
