package Models.Dtos.EngineConfigClasses;

public class UnitActionReward {
    public Integer Farm;
    public Integer Lumber;
    public Integer Stone;
    public Integer Gold;
}
