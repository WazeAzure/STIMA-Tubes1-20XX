package Models.Dtos.EngineConfigClasses;

public class ResourceScoreMultiplier {
    public Integer Population;
    public Integer Food;
    public Integer Wood;
    public Integer Stone;
    public Integer Gold;
}
