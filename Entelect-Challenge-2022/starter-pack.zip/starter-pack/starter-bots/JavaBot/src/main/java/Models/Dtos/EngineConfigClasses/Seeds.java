package Models.Dtos.EngineConfigClasses;

import java.util.List;

public class Seeds {
    public List<Integer> PlayerSeeds;
    public Integer MaxSeed;
    public Integer MinSeed;
}
