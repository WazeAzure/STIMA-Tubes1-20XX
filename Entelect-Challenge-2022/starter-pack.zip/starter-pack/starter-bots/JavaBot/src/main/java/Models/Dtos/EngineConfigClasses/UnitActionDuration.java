package Models.Dtos.EngineConfigClasses;

public class UnitActionDuration {
    public Integer Farm;
    public Integer Scout;
    public Integer Lumber;
    public Integer Mine;
}
