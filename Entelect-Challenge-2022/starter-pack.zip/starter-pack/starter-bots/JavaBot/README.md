# Java Readme

## Installation

To run the Java bot, download Java from 

## Running

To run the Java bot, you can either use **IntelliJ** or any IDE that is able to run Java. If you're using **VSCode** you may need to install the Java extention to run the bot. 

