﻿namespace NETCoreBot.Models
{
    public class World
    {
        public Position CenterPoint { get; set; }
        public int Radius { get; set; }
    }
}
