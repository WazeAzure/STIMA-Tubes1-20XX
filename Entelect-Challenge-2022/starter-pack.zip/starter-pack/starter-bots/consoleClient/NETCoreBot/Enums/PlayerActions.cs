﻿namespace NETCoreBot.Enums
{
    public enum PlayerActions
    {
        Forward = 1,
        Stop = 2
    }
}
