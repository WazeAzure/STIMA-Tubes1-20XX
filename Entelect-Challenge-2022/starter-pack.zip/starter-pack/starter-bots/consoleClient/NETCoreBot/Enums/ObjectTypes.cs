﻿namespace NETCoreBot.Enums
{
    public enum ObjectTypes
    {
        Food = 1,
        Player = 2
    }
}
