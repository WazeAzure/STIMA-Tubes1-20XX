package arctica.service.model

data class Position(
    val x: Int,
    val y: Int
)